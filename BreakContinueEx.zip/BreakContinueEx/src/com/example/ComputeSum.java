package com.example;

import java.util.Scanner;

public class ComputeSum {

    public static void main(String[] args) {
        int x = 0;
        int suma = 0;
        Scanner en = new Scanner(System.in);
        System.out.println("Introduzca 10 números o 0 para terminar: ");
        int num = en.nextInt();
        while(x <= 10){
            x++;
            
           if(num == 0){
               break;
           }
           else{
            suma = suma + num;   
            num = en.nextInt();
            
           }
            
        }
        System.out.println("La suma es: " + suma);
    }
}
