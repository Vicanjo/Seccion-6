
package com.example;

public class Countdown {

    public static void main(String[] args) {
        
        System.out.println("Countdown to Launch: ");
        //5
        for(int i = 0; i <= 5 ; i++) {
            System.out.print(i +" "); 
        }
        System.out.println(" ");
        //20
        System.out.println("Pares");
        for(int i = 0; i <= 20 ; i = i +2) {
            System.out.print(i +" "); 
        }
        System.out.println("Blast Off!");
    }
}
